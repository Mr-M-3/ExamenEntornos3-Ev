package examen3;
 /**
 * La clase Vector2D permite crear un vector a partir de dos Integer , X e Y , e incluye una funcion<br>
 * para crearlos a partir de dos puntos y otra para comprobar si es ortogonal <br>
 * @see <a href="https://es.wikipedia.org/wiki/Vector">Explicacion mas detallada de un vector</a>
 * 
 * 
 * @author MarioMuela
 * @version 20.0.1
 * @since 30/05/2024
 * 
 */

public class Vector2D {
	/**
	 * Crea un objeto Vector2D a partir de dos numeros enteros , X e Y
	 */
	public Integer x, y;
	/**
	 * Crea un objeto Vector2D a partir de dos numeros enteros , X e Y
	 * @param x Integer Cordenada X del punto
	 * @param y Integer Cordenada Y del punto
	 */
	
	Vector2D(Integer x, Integer y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * La clase Vector2D permite crear un vector a partir de dos puntos
	 * @param p1 Point punto uno del que se van a extraer las cordenadas 
	 * @param p2 Point punto dos del que se van a extraer las cordenadas  */
	Vector2D(Point p1,Point p2) {
	
		this.x = p2.x - p1.x;
		this.y = p2.y - p1.y;
	}
	
	/**
	 * Devuelve el producto de un vector
	 * @param v Vector2D vector con el que se calculará
	 * @return Integer con el producto de un vector
	 */
	public int dotProduct(Vector2D v) {
		
		return (x * v.x) + (y * v.y);
	}
	/**
	 * Comprueba si un vector es ortogonal o no
	 * @param v Vector2D vector del que se va a comprobar
	 * @return Boolean true si es un producto ortogonal , false si no lo es
	 */
	public boolean isOrthogonalTo(Vector2D v) {
		
		return (dotProduct(v) == 0);
	}
	
}
