package examen3;
/**
 * La clase point permite crear un punto a partir de dos cordenadas , X e Y
 *  
 * <br>
 * @see <a href="https://es.wikipedia.org/wiki/Punto_(puntuaci%C3%B3n)">Explicacion mas detallada de un punto</a>
 * 
 * 
 * @author MarioMuela
 * @version 20.0.1
 * @since 30/05/2024
 * 
 */

public class Point {
	/**
	 * Permite crear el punto a partir de dos numeros enteros
	 */
	public Integer x, y;
	/**
	 * Permite crear el punto a partir de dos numeros enteros
	 * @param x Integer Cordenada X del punto
	 * @param y Integer Cordenada Y del punto
	 */
	Point(Integer x, Integer y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Crea un Punto a partir de otro Punto que se introduzca, sumandole las cordenadas
	 * @param p Point punto del que se van a extraer las cordenadas
	 * @return Point nuevo punto
	 */
	public Point add(Point p) {
		return new Point(x + p.x, y + p.y);
	}
	
	/**
	 * Crea un Punto a partir de otro Punto que se introduzca, restandole las cordenadas
	 * @param p Point punto del que se van a extraer las cordenadas
	 * @return Point nuevo punto
	 */
	public Point sub(Point p) {
		return new Point(x - p.x, y - p.y);
	}
}
