package examen3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Vector2DTest {

	/*
	 * Declaracion de vectores v1, v2,v3;
	 */
	Vector2D v1, v2, v3;

	/*
	 * Con @Before puedo crear un método setUp() que lance una excepción y en la
	 * cual instanciamos Los vectores v1 (-2,4), v2 (1,2) y v3 (2,1) Los vectores v1
	 * y v3 sin ortogonales por Lo que su producto escalar es 0 Que es lo que vamos
	 * a comprobar más adelante.
	 * 
	 */

	@Before
	public void setUp() throws Exception {
		v1 = new Vector2D(-2, 4);
		v2 = new Vector2D(1, 2);
		v3 = new Vector2D(2, 1);
	}

	@Test
	public void testDotProduct() {
		/*
		 * Con assertEquals vamos a realizar unas pruebas unitarias del producto escalar
		 * que hemos programado con anterioridad. Para ellos vamos acomprobar que el
		 * producto de v1 por v3 es 0 y que el producto de v1 por v2 es....
		 */
		int esperado1 = 0; // el resultado de v1,v3
		int esperado2 = 6; // el resultado de v1,v2
		int producto1 = v1.dotProduct(v3);
		int producto2 = v1.dotProduct(v2);
		assertEquals(esperado1, producto1);
		assertEquals(esperado2, producto2);

	}

	@Test
	public void testOrthogonality() {
		/*
		 * Aqui vamos a comprobar que para los mismos vectores, que el método
		 * isOrtoghonalTo se verifica para los vectores v1 y v3 y para el v2 y v3. Esta
		 * vez debes comprobar con los métodos AssertTrue y AssertFalse con los que
		 * convenga...
		 * 
		 */
		
		boolean producto1 = v1.isOrthogonalTo(v3);// el resultado de v1,v3
		boolean producto2 = v1.isOrthogonalTo(v2);// el resultado de v1,v2

		assertTrue(producto1); //deberia ser true , v1 con v3
		assertFalse(producto2); //deberia ser false ,v1 con v2

	}

}
